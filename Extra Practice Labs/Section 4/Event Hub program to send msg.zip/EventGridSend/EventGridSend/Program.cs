﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EventHubSend
{
    class Program
    {
        static string g_hubname = "demohub";
        static string g_connectstring = "Endpoint=sb://demohubnamespace2020.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=/53J+vgvlwhAu75Zncghgh+g9Oa7Yx3HRw4inb1Do2g=";
        static void Main(string[] args)
        {
            var l_client= EventHubClient.CreateFromConnectionString(g_connectstring, g_hubname);
            int i = 0;
            while (true)
            {
                try
                {
                    i++;
                    var l_message = "This is Test message "+i;
                    Console.WriteLine("Sending message the message: {0}", l_message);
                    l_client.Send(new EventData(Encoding.UTF8.GetBytes(l_message)));
                }
                catch (Exception l_exception)
                {
                    Console.WriteLine(l_exception.Message);
                }

                Thread.Sleep(300);
            }
        }
    }
}
