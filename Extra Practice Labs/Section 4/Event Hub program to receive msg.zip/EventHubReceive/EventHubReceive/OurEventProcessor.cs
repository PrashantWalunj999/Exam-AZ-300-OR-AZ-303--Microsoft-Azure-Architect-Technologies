﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHubReceive
{
    class OurEventProcessor : IEventProcessor
    {
        Stopwatch l_checkpoint;
        async Task IEventProcessor.CloseAsync(PartitionContext context, CloseReason reason)
        {
            Console.WriteLine("The Processor is shuting down");
            if (reason == CloseReason.Shutdown)
            {
                await context.CheckpointAsync();
            }
            
        }
        Task IEventProcessor.OpenAsync(PartitionContext context)
        {
            Console.WriteLine("The processor is initialized");
            this.l_checkpoint = new Stopwatch();
            this.l_checkpoint.Start();
            return Task.FromResult<object>(null);
        }
        async Task IEventProcessor.ProcessEventsAsync(PartitionContext context, IEnumerable<EventData> messages)
        {
            foreach (EventData l_eventData in messages)
            {
                string l_data = Encoding.UTF8.GetString(l_eventData.GetBytes());

                Console.WriteLine(string.Format("Message received. The message data is {0}",l_data));
            }

            
            if (this.l_checkpoint.Elapsed > TimeSpan.FromMinutes(1))
            {
                await context.CheckpointAsync();
                this.l_checkpoint.Restart();
            }
        }
    }
}
