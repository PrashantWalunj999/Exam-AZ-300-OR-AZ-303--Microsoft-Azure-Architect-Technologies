﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHubReceive
{
    // This program will make use of the Event Processor Host Class
    /*
     * The Event Processor Host is a .NET class that simplifies receiving events from event hubs 
     * by managing persistent checkpoints and parallel receives from those event hubs
     * 
     * */
    class Program
    {
        static string g_hubname = "demohub";
        // This is the connection string for the hub
        static string g_connectstring = "Endpoint=sb://demohubnamespace2020.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=/53J+vgvlwhAu75Zncghgh+g9Oa7Yx3HRw4inb1Do2g=";
        // This is the connection string for the storage account
        static string g_storageconnstring = "DefaultEndpointsProtocol=https;AccountName=eventhubstorage2020;AccountKey=qAngg8rvZMbRBPpFpbJ2J9jbn9HwxVDGvwBvmC+ViEkHZ95qm0Ih6meX27i9n+r76W9svZ1xO37xHTWHs3n0nQ==;EndpointSuffix=core.windows.net";
        static void Main(string[] args)
        {
            string eventProcessorHostName = "EventProcessor2020";
            EventProcessorHost l_eventProcessor = new EventProcessorHost(eventProcessorHostName, g_hubname, EventHubConsumerGroup.DefaultGroupName, g_connectstring, g_storageconnstring);

            // Here we are registering the procesor
            var l_options = new EventProcessorOptions();
            l_options.ExceptionReceived += (sender, e) => { Console.WriteLine(e.Exception); };
            l_eventProcessor.RegisterEventProcessorAsync<OurEventProcessor>(l_options).Wait();

            Console.WriteLine("Receiving the messages");
            Console.ReadLine();
            l_eventProcessor.UnregisterEventProcessorAsync().Wait();
        }
    }
}
